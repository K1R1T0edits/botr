const help = (prefix) => {
	return `
「 *𝗔𝗥𝗥157 - 𝗕𝗢𝗧* 」

 ▷ *informações*
 ▷ Prefix: 「  ${prefix}  」
 ▷ Criador : 𝘉𝘙𝘜𝘟𝘐𝘕𝘏𝘖 𝘔𝘖𝘋𝘚
 ▷ 𝘔𝘌𝘜 𝘊𝘈𝘕𝘈𝘓 𝘋𝘈 𝘜𝘔𝘈 𝘍𝘖𝘙𝘊𝘈 𝘓𝘈 𝘍𝘔𝘓 https://youtube.com/channel/UCalQOjX5BFqim6x8JyCMM-w
❖ ── ✦ ──『✙』── ✦ ── ❖
▷ 𝗢𝗨𝗧𝗥𝗢𝗦 𝗠𝗘𝗡𝗨𝗦
*╔═══❖•ೋ° °ೋ•❖═══╗*
☛ menuadmin
☛ nsfwmenu
☛ paulomenu
*╚═══❖•ೋ° °ೋ•❖═══╝*
✦ *𝗦𝗢𝗕𝗥𝗘*
  ▋
  ▋▰ ☛ ${prefix}info
  ▋▰ ☛ ${prefix}blocklist
  ▋▰ ☛ ${prefix}chatlist
  ▋▰ ☛ ${prefix}ping
  ▋▰ ☛ ${prefix}bugreport
✦ *𝗙𝗔𝗭𝗘𝗥*
  ▋
  ▋▰ ☛ ${prefix}sticker
  ▋▰ ☛ ${prefix}stickergif
  ▋▰ ☛ ${prefix}toimg
  ▋▰ ☛ ${prefix}tomp3
  ▋▰ ☛ ${prefix}bpink
  ▋▰ ☛ ${prefix}marvellogo
  ▋▰ ☛ ${prefix}snowwrite
  ▋▰ ☛ ${prefix}3dtext
  ▋▰ ☛ ${prefix}ninjalogo
  ▋▰ ☛ ${prefix}water
  ▋▰ ☛ ${prefix}firetext
  ▋▰ ☛ ${prefix}logowolf
  ▋▰ ☛ ${prefix}logowolf2
  ▋▰ ☛ ${prefix}phlogo
  ▋▰ ☛ ${prefix}glitch
  ▋▰ ☛ ${prefix}neonlogo
  ▋▰ ☛ ${prefix}neonlogo2
  ▋▰ ☛ ${prefix}lionlogo
  ▋▰ ☛ ${prefix}jokerlogo
  ▋▰ ☛ ${prefix}shadow
  ▋▰ ☛ ${prefix}burnpaper
  ▋▰ ☛ ${prefix}coffee
  ▋▰ ☛ ${prefix}lovepaper
  ▋▰ ☛ ${prefix}woodblock
  ▋▰ ☛ ${prefix}qowheart
  ▋▰ ☛ ${prefix}mutgrass
  ▋▰ ☛ ${prefix}undergocean
  ▋▰ ☛ ${prefix}woodenboards
  ▋▰ ☛ ${prefix}wolfmetal
  ▋▰ ☛ ${prefix}metalictglow
  ▋▰ ☛ ${prefix}8bit
  ▋▰ ☛ ${prefix}ttp
  ▋▰ ☛ ${prefix}herrypotter
  ▋▰ ☛ ${prefix}pubglogo
  ▋▰ ☛ ${prefix}quotemaker
✦ *𝗠𝗜𝗗𝗜𝗔*
  ▋
  ▋▰ ☛ ${prefix}trendtwit
  ▋▰ ☛ ${prefix}randomkpop
  ▋▰ ☛ ${prefix}ytsearch
✦ *𝗘𝗗𝗨𝗖𝗔𝗖𝗔𝗢*
  ▋
  ▋▰ ☛ ${prefix}wiki
  ▋▰ ☛ ${prefix}wikien
  ▋▰ ☛ ${prefix}nulis
  ▋▰ ☛ ${prefix}quotes
  ▋▰ ☛ ${prefix}quotes2
  ▋▰ ☛ ${prefix}artinama
✦ *𝗞𝗘𝗥𝗔𝗡𝗚 𝗔𝗝𝗔𝗜𝗕*
  ▋
  ▋▰ ☛ ${prefix}apakah
  ▋▰ ☛ ${prefix}kapankah
  ▋▰ ☛ ${prefix}rate
  ▋▰ ☛ ${prefix}bisakah
✦ *𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗘𝗥*
  ▋▰
  ▋▰ ☛ ${prefix}images
  ▋▰ ☛ ${prefix}ytmp3
  ▋▰ ☛ ${prefix}ytmp4
  ▋▰ ☛ ${prefix}tiktok
  ▋▰ ☛ ${prefix}joox
✦ *𝗠𝗘𝗠𝗘*
  ▋
  ▋▰ ☛ ${prefix}meme
  ▋▰ ☛ ${prefix}memeindo
✦ *𝗦𝗢𝗠*
  ▋
  ▋▰ ☛ ${prefix}play
  ▋▰ ☛ ${prefix}tts
✦ *𝗠𝗨𝗦𝗜𝗖𝗔*
  ▋
  ▋▰ ☛ ${prefix}lirik
  ▋▰ ☛ ${prefix}chord
✦ *𝗜𝗦𝗟𝗔𝗠𝗜𝗦𝗠𝗢*
  ▋
  ▋▰ ☛ ${prefix}quran
✦ *𝗦𝗧𝗔𝗟𝗞*
  ▋ 
  ▋▰ ☛ ${prefix}tiktokstalk
  ▋▰ ☛ ${prefix}igstalk
✦ *𝗪𝗜𝗕𝗨*
  ▋
  ▋▰ ☛ ${prefix}neonime
  ▋▰ ☛ ${prefix}pokemon
  ▋▰ ☛ ${prefix}loli
  ▋▰ ☛ ${prefix}waifu
  ▋▰ ☛ ${prefix}randomanime
  ▋▰ ☛ ${prefix}husbu
  ▋▰ ☛ ${prefix}husbu2
  ▋▰ ☛ ${prefix}wait
  ▋▰ ☛ ${prefix}nekonime
✦ *𝗗𝗜𝗩𝗘𝗥𝗦𝗔𝗢*
  ▋
  ▋▰ ☛ ${prefix}alay
  ▋▰ ☛ ${prefix}gantengcek
  ▋▰ ☛ ${prefix}watak
  ▋▰ ☛ ${prefix}hobby
  ▋▰ ☛ ${prefix}game
  ▋▰ ☛ ${prefix}bucin
  ▋▰ ☛ ${prefix}trust
  ▋▰ ☛ ${prefix}dare
  ▋▰ ☛ ${prefix}simi
✦ *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗔𝗢*
  ▋
  ▋▰ ☛ ${prefix}bahasa
  ▋▰ ☛ ${prefix}kodenegara
  ▋▰ ☛ ${prefix}kbbi
  ▋▰ ☛ ${prefix}fakta
  ▋▰ ☛ ${prefix}infocuaca
  ▋▰ ☛ ${prefix}infogempa
  ▋▰ ☛ ${prefix}jadwaltvnow
  ▋▰ ☛ ${prefix}covid
✦ *𝗗𝗢𝗡𝗢*
  ▋
  ▋▰ ☛ ${prefix}setprefix
  ▋▰ ☛ ${prefix}block
  ▋▰ ☛ ${prefix}bc
  ▋▰ ☛ ${prefix}bcgc
  ▋▰ ☛ ${prefix}clone
  ▋▰ ☛ ${prefix}clearall
✦ *𝗢𝗨𝗧𝗥𝗢𝗦*
  ▋
  ▋▰ ☛ ${prefix}send
  ▋▰ ☛ ${prefix}wame
  ▋▰ ☛ ${prefix}virtex
  ▋▰ ☛ ${prefix}exe
  ▋▰ ☛ ${prefix}qrcode
  ▋▰ ☛ ${prefix}afk
  ▋▰ ☛ ${prefix}timer
  ▋▰ ☛ ${prefix}fml
  ▋▰ ☛ ${prefix}fml2
❖ ── ✦ ──『✙』── ✦ ── ❖
`
}

exports.help = help
